"use strict";
var __StripeExtExports = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
    get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
  }) : x)(function(x) {
    if (typeof require !== "undefined")
      return require.apply(this, arguments);
    throw new Error('Dynamic require of "' + x + '" is not supported');
  });
  var __commonJS = (cb, mod) => function __require2() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // node_modules/@stripe/ui-extension-sdk/version.js
  var require_version = __commonJS({
    "node_modules/@stripe/ui-extension-sdk/version.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.SDK_VERSION = void 0;
      exports.SDK_VERSION = "8.10.0";
    }
  });

  // node_modules/@stripe/ui-extension-sdk/ui/index.js
  var require_ui = __commonJS({
    "node_modules/@stripe/ui-extension-sdk/ui/index.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.Tooltip = exports.TextField = exports.TextArea = exports.Tabs = exports.TableRow = exports.Table = exports.TableHeaderCell = exports.TableHead = exports.TableFooter = exports.TableCell = exports.TableBody = exports.Tab = exports.TabPanels = exports.TabPanel = exports.TabList = exports.Switch = exports.StripeFileUploader = exports.Spinner = exports.Sparkline = exports.SignInView = exports.SettingsView = exports.Select = exports.Radio = exports.Menu = exports.MenuItem = exports.MenuGroup = exports.List = exports.ListItem = exports.Link = exports.LineChart = exports.Inline = exports.Img = exports.Icon = exports.FormFieldGroup = exports.FocusView = exports.Divider = exports.DateField = exports.ContextView = exports.Chip = exports.ChipList = exports.Checkbox = exports.Button = exports.ButtonGroup = exports.Box = exports.BarChart = exports.Banner = exports.Badge = exports.Accordion = exports.AccordionItem = void 0;
      var jsx_runtime_1 = __require("react/jsx-runtime");
      var react_1 = __require("@remote-ui/react");
      var version_1 = require_version();
      var withSdkProps = (Component) => {
        const wrappedComponentName = Component.displayName || Component.toString();
        const WithSdkProps = (props) => (0, jsx_runtime_1.jsx)(Component, Object.assign({}, props, { wrappedComponentName, sdkVersion: version_1.SDK_VERSION, schemaVersion: "v8" }));
        WithSdkProps.wrappedComponentName = wrappedComponentName;
        return WithSdkProps;
      };
      var defineComponent = (name, fragmentProps, wrapWithSdkProps) => {
        const remoteComponent = (0, react_1.createRemoteReactComponent)(name, {
          fragmentProps
        });
        if (!wrapWithSdkProps) {
          return remoteComponent;
        }
        return withSdkProps(remoteComponent);
      };
      exports.AccordionItem = defineComponent("AccordionItem", ["title", "actions", "media", "subtitle"], true);
      exports.Accordion = defineComponent("Accordion", [], true);
      exports.Badge = defineComponent("Badge", [], true);
      exports.Banner = defineComponent("Banner", ["actions", "description", "title"], true);
      exports.BarChart = defineComponent("BarChart", [], true);
      exports.Box = defineComponent("Box", [], true);
      exports.ButtonGroup = defineComponent("ButtonGroup", ["menuTrigger"], true);
      exports.Button = defineComponent("Button", [], true);
      exports.Checkbox = defineComponent("Checkbox", ["label"], true);
      exports.ChipList = defineComponent("ChipList", [], true);
      exports.Chip = defineComponent("Chip", [], true);
      exports.ContextView = defineComponent("ContextView", ["actions", "banner", "footerContent", "primaryAction", "secondaryAction"], true);
      exports.DateField = defineComponent("DateField", ["label"], true);
      exports.Divider = defineComponent("Divider", [], true);
      exports.FocusView = defineComponent("FocusView", ["footerContent", "primaryAction", "secondaryAction"], true);
      exports.FormFieldGroup = defineComponent("FormFieldGroup", [], true);
      exports.Icon = defineComponent("Icon", [], true);
      exports.Img = defineComponent("Img", [], true);
      exports.Inline = defineComponent("Inline", [], true);
      exports.LineChart = defineComponent("LineChart", [], true);
      exports.Link = defineComponent("Link", [], true);
      exports.ListItem = defineComponent("ListItem", ["icon", "image", "secondaryTitle", "title", "value"], true);
      exports.List = defineComponent("List", [], true);
      exports.MenuGroup = defineComponent("MenuGroup", ["title"], true);
      exports.MenuItem = defineComponent("MenuItem", [], true);
      exports.Menu = defineComponent("Menu", ["trigger"], true);
      exports.Radio = defineComponent("Radio", ["label"], true);
      exports.Select = defineComponent("Select", ["label"], true);
      exports.SettingsView = defineComponent("SettingsView", [], true);
      exports.SignInView = defineComponent("SignInView", ["descriptionActionContents", "footerContent"], true);
      exports.Sparkline = defineComponent("Sparkline", [], true);
      exports.Spinner = defineComponent("Spinner", [], true);
      exports.StripeFileUploader = defineComponent("StripeFileUploader", [], true);
      exports.Switch = defineComponent("Switch", ["label"], true);
      exports.TabList = defineComponent("TabList", [], true);
      exports.TabPanel = defineComponent("TabPanel", [], true);
      exports.TabPanels = defineComponent("TabPanels", [], true);
      exports.Tab = defineComponent("Tab", [], true);
      exports.TableBody = defineComponent("TableBody", [], true);
      exports.TableCell = defineComponent("TableCell", [], true);
      exports.TableFooter = defineComponent("TableFooter", [], true);
      exports.TableHead = defineComponent("TableHead", [], true);
      exports.TableHeaderCell = defineComponent("TableHeaderCell", [], true);
      exports.Table = defineComponent("Table", [], true);
      exports.TableRow = defineComponent("TableRow", [], true);
      exports.Tabs = defineComponent("Tabs", [], true);
      exports.TextArea = defineComponent("TextArea", ["label"], true);
      exports.TextField = defineComponent("TextField", ["label"], true);
      exports.Tooltip = defineComponent("Tooltip", ["trigger"], true);
    }
  });

  // .build/manifest.js
  var manifest_exports = {};
  __export(manifest_exports, {
    AppSettings: () => AppSettings_default,
    BUILD_TIME: () => BUILD_TIME,
    DrawerDefaultView: () => DrawerDefaultView_default,
    default: () => manifest_default
  });

  // src/views/AppSettings.tsx
  var import_ui = __toESM(require_ui());
  var import_jsx_runtime = __require("react/jsx-runtime");
  var AppSettings = () => {
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Box, {
      children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Box, {
          css: {
            background: "container",
            padding: "large",
            borderRadius: "medium",
            width: "fit"
          },
          children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Box, {
              css: {
                font: "heading",
                stack: "x",
                alignY: "center",
                gap: "small",
                marginBottom: "small"
              },
              children: [
                /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Icon, {
                  name: "sparkle"
                }),
                "Welcome!"
              ]
            }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Box, {
              children: "We're grateful for your trust in combining SAP and Stripe's solutions. Your commitment to innovation drives us to deliver seamless payment experiences that empower your business. Thank you for being part of our integrated ecosystem."
            }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Box, {
              css: {
                stack: "x",
                gap: "small",
                marginTop: "medium"
              },
              children: [
                /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Button, {
                  type: "primary",
                  target: "_blank",
                  href: "https://help.sap.com/docs/OPEN_PAYMENT_FRAMEWORK",
                  children: [
                    "View OPF integration instructions",
                    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Icon, {
                      name: "external"
                    })
                  ]
                }),
                /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Button, {
                  type: "primary",
                  target: "_blank",
                  href: "https://github.com/SAP-samples/open-payment-framework-integration/tree/main/postman/stripe",
                  children: [
                    "OPF Stripe Integration samples",
                    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Icon, {
                      name: "external"
                    })
                  ]
                })
              ]
            })
          ]
        }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Box, {
          css: { marginTop: "large" },
          children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Box, {
              css: { font: "heading", marginBottom: "small" },
              children: "Introduction"
            }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Divider, {}),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Box, {
              css: { font: "body", marginTop: "medium", marginLeft: 10 },
              children: "This app is designed to facilitate the integration of SAP Commerce Cloud, open payment framework(OPF) with Stripe."
            })
          ]
        }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Box, {
          css: { marginTop: "large" },
          children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Box, {
              css: { font: "heading", marginBottom: "small" },
              children: "Key Features"
            }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Divider, {}),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Box, {
              css: { font: "body", marginTop: "small", marginLeft: 10 },
              children: "\u2022 Generate a secure API credential for seamless authentication with Stripe"
            }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Box, {
              css: { font: "body", marginTop: "small", marginLeft: 10 },
              children: "\u2022 Secure API access with properly scoped permissions"
            }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Box, {
              css: { font: "body", marginTop: "small", marginLeft: 10 },
              children: "\u2022 Simplified integration process for OPF users"
            })
          ]
        }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Box, {
          css: { marginTop: "large" },
          children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Box, {
              css: { font: "heading", marginBottom: "small" },
              children: "User Requirements"
            }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Divider, {}),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Box, {
              css: { font: "body", marginTop: "small", marginLeft: 10 },
              children: "This app is essential for all OPF users planning to integrate their systems with Stripe. Users should have administrator access to their Stripe account and a basic understanding of API authentication principles."
            })
          ]
        }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Box, {
          css: { marginTop: "large" },
          children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Box, {
              css: { font: "heading", marginBottom: "small" },
              children: "Integration Guide"
            }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Divider, {}),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Box, {
              css: { font: "body", marginTop: "small", marginLeft: 10 },
              children: "The generated Access API credential should be added to your OPF configuration in the Stripe integration section. This key allows OPF to make authenticated requests to Stripe's API on your behalf, while limiting access to only the necessary endpoints required for payment processing."
            })
          ]
        }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Box, {
          css: { marginTop: "large" },
          children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Box, {
              css: { font: "heading", marginBottom: "small" },
              children: "Getting Started"
            }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Divider, {}),
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Box, {
              css: { font: "body", marginTop: "small", marginLeft: 10 },
              children: [
                '1. Click the "',
                /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Inline, {
                  css: { fontWeight: "bold" },
                  children: "View API Keys"
                }),
                '" button on upper right corner.'
              ]
            }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Box, {
              css: { font: "body", marginTop: "small", marginLeft: 10 },
              children: [
                "2. Copy both your ",
                /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Inline, {
                  css: { fontWeight: "bold" },
                  children: "Publishable Key"
                }),
                " and the generated ",
                /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Inline, {
                  css: { fontWeight: "bold" },
                  children: "Restricted Key"
                }),
                "."
              ]
            }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Box, {
              css: { font: "body", marginTop: "small", marginLeft: 10 },
              children: [
                "3. Open the ",
                /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Inline, {
                  css: { fontWeight: "bold" },
                  children: "Open Payment Framework workbench"
                }),
                " in your environment."
              ]
            }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Box, {
              css: { font: "body", marginTop: "small", marginLeft: 10 },
              children: [
                '4. Navigate to the "',
                /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Inline, {
                  css: { fontWeight: "bold" },
                  children: "Manage Variables"
                }),
                '" section in the OPF workbench and update the ',
                /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Inline, {
                  css: { fontWeight: "bold" },
                  children: "API key"
                }),
                " configuration."
              ]
            }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Box, {
              css: { font: "body", marginTop: "small", marginLeft: 10 },
              children: "5. Test the integration to ensure proper authentication."
            })
          ]
        }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Box, {
          css: { marginTop: "large" },
          children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Box, {
              css: { font: "heading", marginBottom: "small" },
              children: "Rotate API Key"
            }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Divider, {}),
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Box, {
              css: { font: "body", marginTop: "small", marginLeft: 10 },
              children: [
                "In the Stripe Dashboard, locate ",
                /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Inline, {
                  css: { fontWeight: "bold" },
                  children: "Developers"
                }),
                " in the bottom-left corner and open it. Select ",
                /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Inline, {
                  css: { fontWeight: "bold" },
                  children: "API Keys"
                }),
                ", where you can find all API keys associated with the account. In the ",
                /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Inline, {
                  css: { fontWeight: "bold" },
                  children: "Restricted keys"
                }),
                ' section, find the key named "',
                /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Inline, {
                  css: { fontWeight: "bold" },
                  children: "Key for com.sap.opf"
                }),
                '" with the ',
                /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Inline, {
                  css: { fontWeight: "bold" },
                  children: "App"
                }),
                " tag, then click the three-dot menu at the end of the row and select Rotate."
              ]
            })
          ]
        }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Box, {
          css: { marginTop: "large" },
          children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Box, {
              css: { font: "heading", marginBottom: "small" },
              children: "About OPF"
            }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Divider, {}),
            /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_ui.Box, {
              css: { font: "body", marginTop: "small", marginLeft: 10 },
              children: [
                "SAP Commerce Cloud, open payment framework, is a SaaS solution for managing your payment integrations in an intuitive and effective way. For detailed integration instructions, please refer to the ",
                /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Link, {
                  href: "https://help.sap.com/docs/OPEN_PAYMENT_FRAMEWORK",
                  target: "_blank",
                  children: " Open Payment Framework Documentation"
                }),
                " and ",
                /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_ui.Link, {
                  href: "https://github.com/SAP-samples/open-payment-framework-integration/tree/main/postman/stripe",
                  target: "_blank",
                  children: " Open Payment Framework Integration samples"
                }),
                "."
              ]
            })
          ]
        })
      ]
    });
  };
  var AppSettings_default = AppSettings;

  // src/views/DrawerDefaultView.tsx
  var import_ui2 = __toESM(require_ui());
  var import_jsx_runtime2 = __require("react/jsx-runtime");
  var DrawerDefaultView = ({ userContext, environment }) => {
    return /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_ui2.ContextView, {
      title: "SAP Open Payment Framework",
      children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Box, {
          css: {
            background: "surface",
            borderRadius: "medium",
            wordBreak: "break-all",
            font: "subheading",
            padding: "xsmall",
            color: "secondary"
          },
          children: "This app is for supporting user who integrate Stripe with SAP Open Payment Framework."
        }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Divider, {}),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_ui2.Box, {
          css: {
            font: "body",
            color: "primary",
            fontWeight: "semibold",
            borderRadius: "medium",
            marginTop: "small",
            padding: "medium",
            wordBreak: "normal"
          },
          children: "\u{1F4A1} Please click the button with \xB7\xB7\xB7 in the upper right corner and then go to the app settings page to check API key and other detailed information."
        })
      ]
    });
  };
  var DrawerDefaultView_default = DrawerDefaultView;

  // .build/manifest.js
  __reExport(manifest_exports, __toESM(require_version()));
  var BUILD_TIME = "2025-12-20 11:15:46.21939 +0800 CST m=+1.025061335";
  var manifest_default = {
    "connect_permissions": null,
    "distribution_type": "private",
    "icon": "./sap_logo.png",
    "id": "com.sap.opf",
    "name": "SAP Open Payment Framework",
    "permissions": [
      {
        "permission": "customer_write",
        "purpose": "To create and update customer records"
      },
      {
        "permission": "payment_intent_write",
        "purpose": "To create and manage payment intents"
      },
      {
        "permission": "charge_write",
        "purpose": "Grants access to Charges"
      }
    ],
    "sandbox_install_compatible": true,
    "stripe_api_access_type": "restricted_api_key",
    "ui_extension": {
      "content_security_policy": {
        "connect-src": null,
        "image-src": null,
        "purpose": ""
      },
      "views": [
        {
          "component": "AppSettings",
          "viewport": "settings"
        },
        {
          "component": "DrawerDefaultView",
          "viewport": "stripe.dashboard.drawer.default"
        }
      ]
    },
    "version": "0.0.2"
  };
  return __toCommonJS(manifest_exports);
})();
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vbm9kZV9tb2R1bGVzL0BzdHJpcGUvc3JjL3ZlcnNpb24udHMiLCAiLi4vbm9kZV9tb2R1bGVzL0BzdHJpcGUvc3JjL3VpL2luZGV4LnRzeCIsICJtYW5pZmVzdC5qcyIsICIuLi9zcmMvdmlld3MvQXBwU2V0dGluZ3MudHN4IiwgIi4uL3NyYy92aWV3cy9EcmF3ZXJEZWZhdWx0Vmlldy50c3giXSwKICAic291cmNlc0NvbnRlbnQiOiBbbnVsbCwgbnVsbCwgIi8vIEFVVE9HRU5FUkFURUQgLSBETyBOT1QgTU9ESUZZXG5pbXBvcnQgQXBwU2V0dGluZ3MgZnJvbSAnLi4vc3JjL3ZpZXdzL0FwcFNldHRpbmdzJztpbXBvcnQgRHJhd2VyRGVmYXVsdFZpZXcgZnJvbSAnLi4vc3JjL3ZpZXdzL0RyYXdlckRlZmF1bHRWaWV3JztcblxuZXhwb3J0ICogZnJvbSAnQHN0cmlwZS91aS1leHRlbnNpb24tc2RrL3ZlcnNpb24nO1xuZXhwb3J0IGNvbnN0IEJVSUxEX1RJTUUgPSAnMjAyNS0xMi0yMCAxMToxNTo0Ni4yMTkzOSArMDgwMCBDU1QgbT0rMS4wMjUwNjEzMzUnO1xuXG5leHBvcnQgeyBcbiAgQXBwU2V0dGluZ3MsXHRcblxuICBEcmF3ZXJEZWZhdWx0Vmlld1x0XG4gfTtcblxuZXhwb3J0IGRlZmF1bHQge1xuICBcImNvbm5lY3RfcGVybWlzc2lvbnNcIjogbnVsbCxcbiAgXCJkaXN0cmlidXRpb25fdHlwZVwiOiBcInByaXZhdGVcIixcbiAgXCJpY29uXCI6IFwiLi9zYXBfbG9nby5wbmdcIixcbiAgXCJpZFwiOiBcImNvbS5zYXAub3BmXCIsXG4gIFwibmFtZVwiOiBcIlNBUCBPcGVuIFBheW1lbnQgRnJhbWV3b3JrXCIsXG4gIFwicGVybWlzc2lvbnNcIjogW1xuICAgIHtcbiAgICAgIFwicGVybWlzc2lvblwiOiBcImN1c3RvbWVyX3dyaXRlXCIsXG4gICAgICBcInB1cnBvc2VcIjogXCJUbyBjcmVhdGUgYW5kIHVwZGF0ZSBjdXN0b21lciByZWNvcmRzXCJcbiAgICB9LFxuICAgIHtcbiAgICAgIFwicGVybWlzc2lvblwiOiBcInBheW1lbnRfaW50ZW50X3dyaXRlXCIsXG4gICAgICBcInB1cnBvc2VcIjogXCJUbyBjcmVhdGUgYW5kIG1hbmFnZSBwYXltZW50IGludGVudHNcIlxuICAgIH0sXG4gICAge1xuICAgICAgXCJwZXJtaXNzaW9uXCI6IFwiY2hhcmdlX3dyaXRlXCIsXG4gICAgICBcInB1cnBvc2VcIjogXCJHcmFudHMgYWNjZXNzIHRvIENoYXJnZXNcIlxuICAgIH1cbiAgXSxcbiAgXCJzYW5kYm94X2luc3RhbGxfY29tcGF0aWJsZVwiOiB0cnVlLFxuICBcInN0cmlwZV9hcGlfYWNjZXNzX3R5cGVcIjogXCJyZXN0cmljdGVkX2FwaV9rZXlcIixcbiAgXCJ1aV9leHRlbnNpb25cIjoge1xuICAgIFwiY29udGVudF9zZWN1cml0eV9wb2xpY3lcIjoge1xuICAgICAgXCJjb25uZWN0LXNyY1wiOiBudWxsLFxuICAgICAgXCJpbWFnZS1zcmNcIjogbnVsbCxcbiAgICAgIFwicHVycG9zZVwiOiBcIlwiXG4gICAgfSxcbiAgICBcInZpZXdzXCI6IFtcbiAgICAgIHtcbiAgICAgICAgXCJjb21wb25lbnRcIjogXCJBcHBTZXR0aW5nc1wiLFxuICAgICAgICBcInZpZXdwb3J0XCI6IFwic2V0dGluZ3NcIlxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgXCJjb21wb25lbnRcIjogXCJEcmF3ZXJEZWZhdWx0Vmlld1wiLFxuICAgICAgICBcInZpZXdwb3J0XCI6IFwic3RyaXBlLmRhc2hib2FyZC5kcmF3ZXIuZGVmYXVsdFwiXG4gICAgICB9XG4gICAgXVxuICB9LFxuICBcInZlcnNpb25cIjogXCIwLjAuMlwiXG59O1xuIiwgImltcG9ydCB7XG4gICAgQm94LFxuICAgIEJ1dHRvbixcbiAgICBEaXZpZGVyLFxuICAgIEljb24sXG4gICAgTGluayxcbiAgICBJbmxpbmVcbn0gZnJvbSBcIkBzdHJpcGUvdWktZXh0ZW5zaW9uLXNkay91aVwiO1xuXG5jb25zdCBBcHBTZXR0aW5ncyA9ICgpID0+IHtcbiAgICByZXR1cm4gKFxuICAgICAgICA8Qm94PlxuICAgICAgICAgICAgPEJveFxuICAgICAgICAgICAgICAgIGNzcz17e1xuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBcImNvbnRhaW5lclwiLFxuICAgICAgICAgICAgICAgICAgICBwYWRkaW5nOiBcImxhcmdlXCIsXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogXCJtZWRpdW1cIixcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IFwiZml0XCJcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxCb3hcbiAgICAgICAgICAgICAgICAgICAgY3NzPXt7XG4gICAgICAgICAgICAgICAgICAgICAgICBmb250OiBcImhlYWRpbmdcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0YWNrOiBcInhcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIGFsaWduWTogXCJjZW50ZXJcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIGdhcDogXCJzbWFsbFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgbWFyZ2luQm90dG9tOiBcInNtYWxsXCIsXG4gICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwic3BhcmtsZVwiIC8+XG4gICAgICAgICAgICAgICAgICAgIFdlbGNvbWUhXG4gICAgICAgICAgICAgICAgPC9Cb3g+XG4gICAgICAgICAgICAgICAgPEJveD5cbiAgICAgICAgICAgICAgICAgICAgV2UmYXBvcztyZSBncmF0ZWZ1bCBmb3IgeW91ciB0cnVzdCBpbiBjb21iaW5pbmcgU0FQIGFuZCBTdHJpcGUmYXBvcztzIHNvbHV0aW9ucy4gWW91ciBjb21taXRtZW50IHRvIGlubm92YXRpb24gZHJpdmVzIHVzIHRvIGRlbGl2ZXIgc2VhbWxlc3MgcGF5bWVudCBleHBlcmllbmNlcyB0aGF0IGVtcG93ZXIgeW91ciBidXNpbmVzcy4gVGhhbmsgeW91IGZvciBiZWluZyBwYXJ0IG9mIG91ciBpbnRlZ3JhdGVkIGVjb3N5c3RlbS5cbiAgICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgICAgICA8Qm94XG4gICAgICAgICAgICAgICAgICAgIGNzcz17e1xuICAgICAgICAgICAgICAgICAgICAgICAgc3RhY2s6IFwieFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgZ2FwOiBcInNtYWxsXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW5Ub3A6IFwibWVkaXVtXCIsXG4gICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJwcmltYXJ5XCIgdGFyZ2V0PVwiX2JsYW5rXCIgaHJlZj1cImh0dHBzOi8vaGVscC5zYXAuY29tL2RvY3MvT1BFTl9QQVlNRU5UX0ZSQU1FV09SS1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgVmlldyBPUEYgaW50ZWdyYXRpb24gaW5zdHJ1Y3Rpb25zXG4gICAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiZXh0ZXJuYWxcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cblxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJwcmltYXJ5XCIgdGFyZ2V0PVwiX2JsYW5rXCIgaHJlZj1cImh0dHBzOi8vZ2l0aHViLmNvbS9TQVAtc2FtcGxlcy9vcGVuLXBheW1lbnQtZnJhbWV3b3JrLWludGVncmF0aW9uL3RyZWUvbWFpbi9wb3N0bWFuL3N0cmlwZVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgT1BGIFN0cmlwZSBJbnRlZ3JhdGlvbiBzYW1wbGVzXG4gICAgICAgICAgICAgICAgICAgICAgICA8SWNvbiBuYW1lPVwiZXh0ZXJuYWxcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgICAgPEJveCBjc3M9e3sgbWFyZ2luVG9wOiBcImxhcmdlXCIgfX0+XG4gICAgICAgICAgICAgICAgPEJveCBjc3M9e3sgZm9udDogXCJoZWFkaW5nXCIsIG1hcmdpbkJvdHRvbTogXCJzbWFsbFwiIH19PlxuICAgICAgICAgICAgICAgICAgICBJbnRyb2R1Y3Rpb25cbiAgICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgICAgICA8RGl2aWRlciAvPlxuICAgICAgICAgICAgICAgIDxCb3ggY3NzPXt7IGZvbnQ6IFwiYm9keVwiLCBtYXJnaW5Ub3A6IFwibWVkaXVtXCIsIG1hcmdpbkxlZnQ6IDEwIH19PlxuICAgICAgICAgICAgICAgICAgICBUaGlzIGFwcCBpcyBkZXNpZ25lZCB0byBmYWNpbGl0YXRlIHRoZSBpbnRlZ3JhdGlvbiBvZiBTQVAgQ29tbWVyY2UgQ2xvdWQsIG9wZW4gcGF5bWVudCBmcmFtZXdvcmsoT1BGKSB3aXRoIFN0cmlwZS5cbiAgICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgICAgPEJveCBjc3M9e3sgbWFyZ2luVG9wOiBcImxhcmdlXCIgfX0+XG4gICAgICAgICAgICAgICAgPEJveCBjc3M9e3sgZm9udDogXCJoZWFkaW5nXCIsIG1hcmdpbkJvdHRvbTogXCJzbWFsbFwiIH19PlxuICAgICAgICAgICAgICAgICAgICBLZXkgRmVhdHVyZXNcbiAgICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgICAgICA8RGl2aWRlciAvPlxuICAgICAgICAgICAgICAgIDxCb3ggY3NzPXt7IGZvbnQ6IFwiYm9keVwiLCBtYXJnaW5Ub3A6IFwic21hbGxcIiwgbWFyZ2luTGVmdDogMTAgfX0+XG4gICAgICAgICAgICAgICAgICAgIFx1MjAyMiBHZW5lcmF0ZSBhIHNlY3VyZSBBUEkgY3JlZGVudGlhbCBmb3Igc2VhbWxlc3MgYXV0aGVudGljYXRpb24gd2l0aCBTdHJpcGVcbiAgICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgICAgICA8Qm94IGNzcz17eyBmb250OiBcImJvZHlcIiwgbWFyZ2luVG9wOiBcInNtYWxsXCIsIG1hcmdpbkxlZnQ6IDEwIH19PlxuICAgICAgICAgICAgICAgICAgICBcdTIwMjIgU2VjdXJlIEFQSSBhY2Nlc3Mgd2l0aCBwcm9wZXJseSBzY29wZWQgcGVybWlzc2lvbnNcbiAgICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgICAgICA8Qm94IGNzcz17eyBmb250OiBcImJvZHlcIiwgbWFyZ2luVG9wOiBcInNtYWxsXCIsIG1hcmdpbkxlZnQ6IDEwIH19PlxuICAgICAgICAgICAgICAgICAgICBcdTIwMjIgU2ltcGxpZmllZCBpbnRlZ3JhdGlvbiBwcm9jZXNzIGZvciBPUEYgdXNlcnNcbiAgICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgICAgPEJveCBjc3M9e3sgbWFyZ2luVG9wOiBcImxhcmdlXCIgfX0+XG4gICAgICAgICAgICAgICAgPEJveCBjc3M9e3sgZm9udDogXCJoZWFkaW5nXCIsIG1hcmdpbkJvdHRvbTogXCJzbWFsbFwiIH19PlxuICAgICAgICAgICAgICAgICAgICBVc2VyIFJlcXVpcmVtZW50c1xuICAgICAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgICAgICAgIDxEaXZpZGVyIC8+XG4gICAgICAgICAgICAgICAgPEJveCBjc3M9e3sgZm9udDogXCJib2R5XCIsIG1hcmdpblRvcDogXCJzbWFsbFwiLCBtYXJnaW5MZWZ0OiAxMCB9fT5cbiAgICAgICAgICAgICAgICAgICAgVGhpcyBhcHAgaXMgZXNzZW50aWFsIGZvciBhbGwgT1BGIHVzZXJzIHBsYW5uaW5nIHRvIGludGVncmF0ZSB0aGVpciBzeXN0ZW1zIHdpdGggU3RyaXBlLiBVc2VycyBzaG91bGQgaGF2ZSBhZG1pbmlzdHJhdG9yIGFjY2VzcyB0byB0aGVpciBTdHJpcGUgYWNjb3VudCBhbmQgYSBiYXNpYyB1bmRlcnN0YW5kaW5nIG9mIEFQSSBhdXRoZW50aWNhdGlvbiBwcmluY2lwbGVzLlxuICAgICAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgICAgPC9Cb3g+XG4gICAgICAgICAgICA8Qm94IGNzcz17eyBtYXJnaW5Ub3A6IFwibGFyZ2VcIiB9fT5cbiAgICAgICAgICAgICAgICA8Qm94IGNzcz17eyBmb250OiBcImhlYWRpbmdcIiwgbWFyZ2luQm90dG9tOiBcInNtYWxsXCIgfX0+XG4gICAgICAgICAgICAgICAgICAgIEludGVncmF0aW9uIEd1aWRlXG4gICAgICAgICAgICAgICAgPC9Cb3g+XG4gICAgICAgICAgICAgICAgPERpdmlkZXIgLz5cbiAgICAgICAgICAgICAgICA8Qm94IGNzcz17eyBmb250OiBcImJvZHlcIiwgbWFyZ2luVG9wOiBcInNtYWxsXCIsIG1hcmdpbkxlZnQ6IDEwIH19PlxuICAgICAgICAgICAgICAgICAgICBUaGUgZ2VuZXJhdGVkIEFjY2VzcyBBUEkgY3JlZGVudGlhbCBzaG91bGQgYmUgYWRkZWQgdG8geW91ciBPUEYgY29uZmlndXJhdGlvbiBpbiB0aGUgU3RyaXBlIGludGVncmF0aW9uIHNlY3Rpb24uIFRoaXMga2V5IGFsbG93cyBPUEYgdG8gbWFrZSBhdXRoZW50aWNhdGVkIHJlcXVlc3RzIHRvIFN0cmlwZSZhcG9zO3MgQVBJIG9uIHlvdXIgYmVoYWxmLCB3aGlsZSBsaW1pdGluZyBhY2Nlc3MgdG8gb25seSB0aGUgbmVjZXNzYXJ5IGVuZHBvaW50cyByZXF1aXJlZCBmb3IgcGF5bWVudCBwcm9jZXNzaW5nLlxuICAgICAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgICAgPC9Cb3g+XG4gICAgICAgICAgICA8Qm94IGNzcz17eyBtYXJnaW5Ub3A6IFwibGFyZ2VcIiB9fT5cbiAgICAgICAgICAgICAgICA8Qm94IGNzcz17eyBmb250OiBcImhlYWRpbmdcIiwgbWFyZ2luQm90dG9tOiBcInNtYWxsXCIgfX0+XG4gICAgICAgICAgICAgICAgICAgIEdldHRpbmcgU3RhcnRlZFxuICAgICAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgICAgICAgIDxEaXZpZGVyIC8+XG4gICAgICAgICAgICAgICAgPEJveCBjc3M9e3sgZm9udDogXCJib2R5XCIsIG1hcmdpblRvcDogXCJzbWFsbFwiLCBtYXJnaW5MZWZ0OiAxMCB9fT5cbiAgICAgICAgICAgICAgICAgICAgMS4gQ2xpY2sgdGhlICZxdW90OzxJbmxpbmUgY3NzPXt7IGZvbnRXZWlnaHQ6IFwiYm9sZFwifX0+VmlldyBBUEkgS2V5czwvSW5saW5lPiZxdW90OyBidXR0b24gb24gdXBwZXIgcmlnaHQgY29ybmVyLlxuICAgICAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgICAgICAgIDxCb3ggY3NzPXt7IGZvbnQ6IFwiYm9keVwiLCBtYXJnaW5Ub3A6IFwic21hbGxcIiwgbWFyZ2luTGVmdDogMTAgfX0+XG4gICAgICAgICAgICAgICAgICAgIDIuIENvcHkgYm90aCB5b3VyIDxJbmxpbmUgY3NzPXt7IGZvbnRXZWlnaHQ6IFwiYm9sZFwifX0+UHVibGlzaGFibGUgS2V5PC9JbmxpbmU+IGFuZCB0aGUgZ2VuZXJhdGVkIDxJbmxpbmUgY3NzPXt7IGZvbnRXZWlnaHQ6IFwiYm9sZFwifX0+UmVzdHJpY3RlZCBLZXk8L0lubGluZT4uXG4gICAgICAgICAgICAgICAgPC9Cb3g+XG4gICAgICAgICAgICAgICAgPEJveCBjc3M9e3sgZm9udDogXCJib2R5XCIsIG1hcmdpblRvcDogXCJzbWFsbFwiLCBtYXJnaW5MZWZ0OiAxMCB9fT5cbiAgICAgICAgICAgICAgICAgICAgMy4gT3BlbiB0aGUgPElubGluZSBjc3M9e3sgZm9udFdlaWdodDogXCJib2xkXCJ9fT5PcGVuIFBheW1lbnQgRnJhbWV3b3JrIHdvcmtiZW5jaDwvSW5saW5lPiBpbiB5b3VyIGVudmlyb25tZW50LlxuICAgICAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgICAgICAgIDxCb3ggY3NzPXt7IGZvbnQ6IFwiYm9keVwiLCBtYXJnaW5Ub3A6IFwic21hbGxcIiwgbWFyZ2luTGVmdDogMTAgfX0+XG4gICAgICAgICAgICAgICAgICAgIDQuIE5hdmlnYXRlIHRvIHRoZSAmcXVvdDs8SW5saW5lIGNzcz17eyBmb250V2VpZ2h0OiBcImJvbGRcIn19Pk1hbmFnZSBWYXJpYWJsZXM8L0lubGluZT4mcXVvdDsgc2VjdGlvbiBpbiB0aGUgT1BGIHdvcmtiZW5jaCBhbmQgdXBkYXRlIHRoZSA8SW5saW5lIGNzcz17eyBmb250V2VpZ2h0OiBcImJvbGRcIn19PkFQSSBrZXk8L0lubGluZT4gY29uZmlndXJhdGlvbi5cbiAgICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgICAgICA8Qm94IGNzcz17eyBmb250OiBcImJvZHlcIiwgbWFyZ2luVG9wOiBcInNtYWxsXCIsIG1hcmdpbkxlZnQ6IDEwIH19PlxuICAgICAgICAgICAgICAgICAgICA1LiBUZXN0IHRoZSBpbnRlZ3JhdGlvbiB0byBlbnN1cmUgcHJvcGVyIGF1dGhlbnRpY2F0aW9uLlxuICAgICAgICAgICAgICAgIDwvQm94PlxuICAgICAgICAgICAgPC9Cb3g+XG5cbiAgICAgICAgICAgIDxCb3ggY3NzPXt7IG1hcmdpblRvcDogXCJsYXJnZVwiIH19PlxuICAgICAgICAgICAgICAgIDxCb3ggY3NzPXt7IGZvbnQ6IFwiaGVhZGluZ1wiLCBtYXJnaW5Cb3R0b206IFwic21hbGxcIiB9fT5cbiAgICAgICAgICAgICAgICAgICAgUm90YXRlIEFQSSBLZXlcbiAgICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgICAgICA8RGl2aWRlciAvPlxuICAgICAgICAgICAgICAgIDxCb3ggY3NzPXt7IGZvbnQ6IFwiYm9keVwiLCBtYXJnaW5Ub3A6IFwic21hbGxcIiwgbWFyZ2luTGVmdDogMTAgfX0+XG4gICAgICAgICAgICAgICAgICAgIEluIHRoZSBTdHJpcGUgRGFzaGJvYXJkLCBsb2NhdGUgPElubGluZSBjc3M9e3sgZm9udFdlaWdodDogXCJib2xkXCJ9fT5EZXZlbG9wZXJzPC9JbmxpbmU+IGluIHRoZSBib3R0b20tbGVmdCBjb3JuZXIgYW5kIG9wZW4gaXQuIFNlbGVjdCA8SW5saW5lIGNzcz17eyBmb250V2VpZ2h0OiBcImJvbGRcIn19PkFQSSBLZXlzPC9JbmxpbmU+LCB3aGVyZSB5b3UgY2FuIGZpbmQgYWxsIEFQSSBrZXlzIGFzc29jaWF0ZWQgd2l0aCB0aGUgYWNjb3VudC4gSW4gdGhlIDxJbmxpbmUgY3NzPXt7IGZvbnRXZWlnaHQ6IFwiYm9sZFwifX0+UmVzdHJpY3RlZCBrZXlzPC9JbmxpbmU+IHNlY3Rpb24sIGZpbmQgdGhlIGtleSBuYW1lZCAmcXVvdDs8SW5saW5lIGNzcz17eyBmb250V2VpZ2h0OiBcImJvbGRcIn19PktleSBmb3IgY29tLnNhcC5vcGY8L0lubGluZT4mcXVvdDsgd2l0aCB0aGUgPElubGluZSBjc3M9e3sgZm9udFdlaWdodDogXCJib2xkXCJ9fT5BcHA8L0lubGluZT4gdGFnLCB0aGVuIGNsaWNrIHRoZSB0aHJlZS1kb3QgbWVudSBhdCB0aGUgZW5kIG9mIHRoZSByb3cgYW5kIHNlbGVjdCBSb3RhdGUuXG4gICAgICAgICAgICAgICAgPC9Cb3g+XG4gICAgICAgICAgICA8L0JveD5cblxuICAgICAgICAgICAgPEJveCBjc3M9e3sgbWFyZ2luVG9wOiBcImxhcmdlXCIgfX0+XG4gICAgICAgICAgICAgICAgPEJveCBjc3M9e3sgZm9udDogXCJoZWFkaW5nXCIsIG1hcmdpbkJvdHRvbTogXCJzbWFsbFwiIH19PlxuICAgICAgICAgICAgICAgICAgICBBYm91dCBPUEZcbiAgICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgICAgICA8RGl2aWRlciAvPlxuICAgICAgICAgICAgICAgIDxCb3ggY3NzPXt7IGZvbnQ6IFwiYm9keVwiLCBtYXJnaW5Ub3A6IFwic21hbGxcIiwgbWFyZ2luTGVmdDogMTAgfX0+XG4gICAgICAgICAgICAgICAgICAgIFNBUCBDb21tZXJjZSBDbG91ZCwgb3BlbiBwYXltZW50IGZyYW1ld29yaywgaXMgYSBTYWFTIHNvbHV0aW9uIGZvciBtYW5hZ2luZyB5b3VyIHBheW1lbnQgaW50ZWdyYXRpb25zIGluIGFuIGludHVpdGl2ZSBhbmQgZWZmZWN0aXZlIHdheS5cbiAgICAgICAgICAgICAgICAgICAgRm9yIGRldGFpbGVkIGludGVncmF0aW9uIGluc3RydWN0aW9ucywgcGxlYXNlIHJlZmVyIHRvIHRoZSA8TGluayBocmVmPVwiaHR0cHM6Ly9oZWxwLnNhcC5jb20vZG9jcy9PUEVOX1BBWU1FTlRfRlJBTUVXT1JLXCIgdGFyZ2V0PVwiX2JsYW5rXCI+IE9wZW4gUGF5bWVudCBGcmFtZXdvcmsgRG9jdW1lbnRhdGlvbjwvTGluaz4gYW5kIDxMaW5rIGhyZWY9XCJodHRwczovL2dpdGh1Yi5jb20vU0FQLXNhbXBsZXMvb3Blbi1wYXltZW50LWZyYW1ld29yay1pbnRlZ3JhdGlvbi90cmVlL21haW4vcG9zdG1hbi9zdHJpcGVcIiB0YXJnZXQ9XCJfYmxhbmtcIj4gT3BlbiBQYXltZW50IEZyYW1ld29yayBJbnRlZ3JhdGlvbiBzYW1wbGVzPC9MaW5rPi5cbiAgICAgICAgICAgICAgICA8L0JveD5cbiAgICAgICAgICAgIDwvQm94PlxuICAgICAgICA8L0JveD5cbiAgICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgQXBwU2V0dGluZ3M7IiwgImltcG9ydCB7IEJveCwgQ29udGV4dFZpZXcsIERpdmlkZXIsIEJ1dHRvbiB9IGZyb20gXCJAc3RyaXBlL3VpLWV4dGVuc2lvbi1zZGsvdWlcIjtcbmltcG9ydCB0eXBlIHsgRXh0ZW5zaW9uQ29udGV4dFZhbHVlIH0gZnJvbSBcIkBzdHJpcGUvdWktZXh0ZW5zaW9uLXNkay9jb250ZXh0XCI7XG5cbmNvbnN0IERyYXdlckRlZmF1bHRWaWV3ID0gKHsgdXNlckNvbnRleHQsIGVudmlyb25tZW50IH06IEV4dGVuc2lvbkNvbnRleHRWYWx1ZSkgPT4ge1xuXG4gIHJldHVybiAoXG4gICAgPENvbnRleHRWaWV3XG4gICAgICB0aXRsZT1cIlNBUCBPcGVuIFBheW1lbnQgRnJhbWV3b3JrXCJcbiAgICA+XG4gICAgICA8Qm94XG4gICAgICAgIGNzcz17e1xuICAgICAgICAgIGJhY2tncm91bmQ6IFwic3VyZmFjZVwiLFxuICAgICAgICAgIGJvcmRlclJhZGl1czogXCJtZWRpdW1cIixcbiAgICAgICAgICB3b3JkQnJlYWs6IFwiYnJlYWstYWxsXCIsXG4gICAgICAgICAgZm9udDogJ3N1YmhlYWRpbmcnLFxuICAgICAgICAgIHBhZGRpbmc6IFwieHNtYWxsXCIsXG4gICAgICAgICAgY29sb3I6IFwic2Vjb25kYXJ5XCJcbiAgICAgICAgfX0+XG4gICAgICAgIFRoaXMgYXBwIGlzIGZvciBzdXBwb3J0aW5nIHVzZXIgd2hvIGludGVncmF0ZSBTdHJpcGUgd2l0aCBTQVAgT3BlbiBQYXltZW50IEZyYW1ld29yay5cbiAgICAgIDwvQm94PlxuICAgICAgPERpdmlkZXIvPlxuICAgICAgPEJveFxuICAgICAgICBjc3M9e3tcbiAgICAgICAgICBmb250OiAnYm9keScsXG4gICAgICAgICAgY29sb3I6ICdwcmltYXJ5JyxcbiAgICAgICAgICBmb250V2VpZ2h0OiAnc2VtaWJvbGQnLFxuICAgICAgICAgIGJvcmRlclJhZGl1czogXCJtZWRpdW1cIixcbiAgICAgICAgICBtYXJnaW5Ub3A6IFwic21hbGxcIixcbiAgICAgICAgICBwYWRkaW5nOiBcIm1lZGl1bVwiLFxuICAgICAgICAgIHdvcmRCcmVhazogXCJub3JtYWxcIixcbiAgICAgICAgfX0+XG4gICAgICAgIFx1RDgzRFx1RENBMSBQbGVhc2UgY2xpY2sgdGhlIGJ1dHRvbiB3aXRoIFx1MDBCN1x1MDBCN1x1MDBCNyBpbiB0aGUgdXBwZXIgcmlnaHQgY29ybmVyIGFuZCB0aGVuIGdvIHRvIHRoZSBhcHAgc2V0dGluZ3MgcGFnZSB0byBjaGVjayBBUEkga2V5IGFuZCBvdGhlciBkZXRhaWxlZCBpbmZvcm1hdGlvbi5cbiAgICAgIDwvQm94PlxuICAgIDwvQ29udGV4dFZpZXc+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBEcmF3ZXJEZWZhdWx0VmlldztcbiJdLAogICJtYXBwaW5ncyI6ICI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBYSxjQUFBLGNBQWM7Ozs7Ozs7Ozs7O0FDVTNCLFVBQUEsVUFBQSxVQUFBO0FBQ0EsVUFBQSxZQUFBO0FBRUEsVUFBTSxlQUFlLENBQ25CLGNBQ0U7QUFDRixjQUFNLHVCQUF1QixVQUFVLGVBQWUsVUFBVSxTQUFRO0FBQ3hFLGNBQU0sZUFFRixDQUFDLFdBQ0gsR0FBQSxjQUFBLEtBQUMsV0FBUyxPQUFBLE9BQUEsQ0FBQSxHQUNKLE9BQUssRUFDVCxzQkFDQSxZQUFZLFVBQUEsYUFDWixlQUFjLEtBQUksQ0FBQSxDQUFBO0FBSXRCLHFCQUFhLHVCQUF1QjtBQUVwQyxlQUFPO01BQ1Q7QUFFQSxVQUFNLGtCQUFrQixDQUl0QixNQUNBLGVBQ0EscUJBQ0U7QUFDRixjQUFNLG1CQUFrQixHQUFBLFFBQUEsNEJBQWlDLE1BQU07VUFDN0Q7U0FDRDtBQUVELFlBQUksQ0FBQyxrQkFBa0I7QUFDckIsaUJBQU87UUFDVDtBQUVBLGVBQU8sYUFBYSxlQUFlO01BR3JDO0FBb1dhLGNBQUEsZ0JBQWdCLGdCQUczQixpQkFBaUIsQ0FBQyxTQUFTLFdBQVcsU0FBUyxVQUFVLEdBQUcsSUFBSTtBQVVyRCxjQUFBLFlBQVksZ0JBQ3ZCLGFBQ0EsQ0FBQSxHQUNBLElBQUk7QUFXTyxjQUFBLFFBQVEsZ0JBQXFDLFNBQVMsQ0FBQSxHQUFJLElBQUk7QUFVOUQsY0FBQSxTQUFTLGdCQUNwQixVQUNBLENBQUMsV0FBVyxlQUFlLE9BQU8sR0FDbEMsSUFBSTtBQTBCTyxjQUFBLFdBQVcsZ0JBQ3RCLFlBQ0EsQ0FBQSxHQUNBLElBQUk7QUF3M0JPLGNBQUEsTUFBTSxnQkFBaUMsT0FBTyxDQUFBLEdBQUksSUFBSTtBQWF0RCxjQUFBLGNBQWMsZ0JBQ3pCLGVBQ0EsQ0FBQyxhQUFhLEdBQ2QsSUFBSTtBQWlFTyxjQUFBLFNBQVMsZ0JBQ3BCLFVBQ0EsQ0FBQSxHQUNBLElBQUk7QUF3Q08sY0FBQSxXQUFXLGdCQUN0QixZQUNBLENBQUMsT0FBTyxHQUNSLElBQUk7QUFTTyxjQUFBLFdBQVcsZ0JBQ3RCLFlBQ0EsQ0FBQSxHQUNBLElBQUk7QUFnQk8sY0FBQSxPQUFPLGdCQUFtQyxRQUFRLENBQUEsR0FBSSxJQUFJO0FBZ0MxRCxjQUFBLGNBQWMsZ0JBQ3pCLGVBQ0EsQ0FBQyxXQUFXLFVBQVUsaUJBQWlCLGlCQUFpQixpQkFBaUIsR0FDekUsSUFBSTtBQWlDTyxjQUFBLFlBQVksZ0JBQ3ZCLGFBQ0EsQ0FBQyxPQUFPLEdBQ1IsSUFBSTtBQUtPLGNBQUEsVUFBVSxnQkFDckIsV0FDQSxDQUFBLEdBQ0EsSUFBSTtBQTJCTyxjQUFBLFlBQVksZ0JBQ3ZCLGFBQ0EsQ0FBQyxpQkFBaUIsaUJBQWlCLGlCQUFpQixHQUNwRCxJQUFJO0FBb0JPLGNBQUEsaUJBQWlCLGdCQUc1QixrQkFBa0IsQ0FBQSxHQUFJLElBQUk7QUErUWYsY0FBQSxPQUFPLGdCQUFtQyxRQUFRLENBQUEsR0FBSSxJQUFJO0FBbUIxRCxjQUFBLE1BQU0sZ0JBQWlDLE9BQU8sQ0FBQSxHQUFJLElBQUk7QUF1M0J0RCxjQUFBLFNBQVMsZ0JBQ3BCLFVBQ0EsQ0FBQSxHQUNBLElBQUk7QUEwQk8sY0FBQSxZQUFZLGdCQUN2QixhQUNBLENBQUEsR0FDQSxJQUFJO0FBcUVPLGNBQUEsT0FBTyxnQkFBbUMsUUFBUSxDQUFBLEdBQUksSUFBSTtBQW1CMUQsY0FBQSxXQUFXLGdCQUN0QixZQUNBLENBQUMsUUFBUSxTQUFTLGtCQUFrQixTQUFTLE9BQU8sR0FDcEQsSUFBSTtBQVVPLGNBQUEsT0FBTyxnQkFBbUMsUUFBUSxDQUFBLEdBQUksSUFBSTtBQVExRCxjQUFBLFlBQVksZ0JBQ3ZCLGFBQ0EsQ0FBQyxPQUFPLEdBQ1IsSUFBSTtBQWNPLGNBQUEsV0FBVyxnQkFDdEIsWUFDQSxDQUFBLEdBQ0EsSUFBSTtBQVlPLGNBQUEsT0FBTyxnQkFDbEIsUUFDQSxDQUFDLFNBQVMsR0FDVixJQUFJO0FBZ0RPLGNBQUEsUUFBUSxnQkFDbkIsU0FDQSxDQUFDLE9BQU8sR0FDUixJQUFJO0FBbUZPLGNBQUEsU0FBUyxnQkFDcEIsVUFDQSxDQUFDLE9BQU8sR0FDUixJQUFJO0FBYU8sY0FBQSxlQUFlLGdCQUMxQixnQkFDQSxDQUFBLEdBQ0EsSUFBSTtBQTJCTyxjQUFBLGFBQWEsZ0JBQ3hCLGNBQ0EsQ0FBQyw2QkFBNkIsZUFBZSxHQUM3QyxJQUFJO0FBb0JPLGNBQUEsWUFBWSxnQkFDdkIsYUFDQSxDQUFBLEdBQ0EsSUFBSTtBQVVPLGNBQUEsVUFBVSxnQkFDckIsV0FDQSxDQUFBLEdBQ0EsSUFBSTtBQTJDTyxjQUFBLHFCQUFxQixnQkFHaEMsc0JBQXNCLENBQUEsR0FBSSxJQUFJO0FBd0NuQixjQUFBLFNBQVMsZ0JBQ3BCLFVBQ0EsQ0FBQyxPQUFPLEdBQ1IsSUFBSTtBQVFPLGNBQUEsVUFBVSxnQkFDckIsV0FDQSxDQUFBLEdBQ0EsSUFBSTtBQWNPLGNBQUEsV0FBVyxnQkFDdEIsWUFDQSxDQUFBLEdBQ0EsSUFBSTtBQVFPLGNBQUEsWUFBWSxnQkFDdkIsYUFDQSxDQUFBLEdBQ0EsSUFBSTtBQWdCTyxjQUFBLE1BQU0sZ0JBQWlDLE9BQU8sQ0FBQSxHQUFJLElBQUk7QUFPdEQsY0FBQSxZQUFZLGdCQUN2QixhQUNBLENBQUEsR0FDQSxJQUFJO0FBZ0JPLGNBQUEsWUFBWSxnQkFDdkIsYUFDQSxDQUFBLEdBQ0EsSUFBSTtBQVFPLGNBQUEsY0FBYyxnQkFDekIsZUFDQSxDQUFBLEdBQ0EsSUFBSTtBQVFPLGNBQUEsWUFBWSxnQkFDdkIsYUFDQSxDQUFBLEdBQ0EsSUFBSTtBQWdCTyxjQUFBLGtCQUFrQixnQkFHN0IsbUJBQW1CLENBQUEsR0FBSSxJQUFJO0FBVWhCLGNBQUEsUUFBUSxnQkFBcUMsU0FBUyxDQUFBLEdBQUksSUFBSTtBQU85RCxjQUFBLFdBQVcsZ0JBQ3RCLFlBQ0EsQ0FBQSxHQUNBLElBQUk7QUFnQk8sY0FBQSxPQUFPLGdCQUFtQyxRQUFRLENBQUEsR0FBSSxJQUFJO0FBd0cxRCxjQUFBLFdBQVcsZ0JBQ3RCLFlBQ0EsQ0FBQyxPQUFPLEdBQ1IsSUFBSTtBQXlHTyxjQUFBLFlBQVksZ0JBQ3ZCLGFBQ0EsQ0FBQyxPQUFPLEdBQ1IsSUFBSTtBQXlDTyxjQUFBLFVBQVUsZ0JBQ3JCLFdBQ0EsQ0FBQyxTQUFTLEdBQ1YsSUFBSTs7Ozs7QUNycEhOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBOzs7QUNBQSxrQkFPTztBQWFTO0FBWGhCLE1BQU0sY0FBYyxNQUFNO0FBQ3RCLFdBQ0ksNkNBQUM7QUFBQSxNQUNHO0FBQUEscURBQUM7QUFBQSxVQUNHLEtBQUs7QUFBQSxZQUNELFlBQVk7QUFBQSxZQUNaLFNBQVM7QUFBQSxZQUNULGNBQWM7QUFBQSxZQUNkLE9BQU87QUFBQSxVQUNYO0FBQUEsVUFFQTtBQUFBLHlEQUFDO0FBQUEsY0FDRyxLQUFLO0FBQUEsZ0JBQ0QsTUFBTTtBQUFBLGdCQUNOLE9BQU87QUFBQSxnQkFDUCxRQUFRO0FBQUEsZ0JBQ1IsS0FBSztBQUFBLGdCQUNMLGNBQWM7QUFBQSxjQUNsQjtBQUFBLGNBRUE7QUFBQSw0REFBQztBQUFBLGtCQUFLLE1BQUs7QUFBQSxpQkFBVTtBQUFBLGdCQUFFO0FBQUE7QUFBQSxhQUUzQjtBQUFBLFlBQ0EsNENBQUM7QUFBQSxjQUFJO0FBQUEsYUFFTDtBQUFBLFlBQ0EsNkNBQUM7QUFBQSxjQUNHLEtBQUs7QUFBQSxnQkFDRCxPQUFPO0FBQUEsZ0JBQ1AsS0FBSztBQUFBLGdCQUNMLFdBQVc7QUFBQSxjQUNmO0FBQUEsY0FFQTtBQUFBLDZEQUFDO0FBQUEsa0JBQU8sTUFBSztBQUFBLGtCQUFVLFFBQU87QUFBQSxrQkFBUyxNQUFLO0FBQUEsa0JBQW1EO0FBQUE7QUFBQSxvQkFFM0YsNENBQUM7QUFBQSxzQkFBSyxNQUFLO0FBQUEscUJBQVc7QUFBQTtBQUFBLGlCQUMxQjtBQUFBLGdCQUVBLDZDQUFDO0FBQUEsa0JBQU8sTUFBSztBQUFBLGtCQUFVLFFBQU87QUFBQSxrQkFBUyxNQUFLO0FBQUEsa0JBQTZGO0FBQUE7QUFBQSxvQkFFckksNENBQUM7QUFBQSxzQkFBSyxNQUFLO0FBQUEscUJBQVc7QUFBQTtBQUFBLGlCQUMxQjtBQUFBO0FBQUEsYUFDSjtBQUFBO0FBQUEsU0FDSjtBQUFBLFFBQ0EsNkNBQUM7QUFBQSxVQUFJLEtBQUssRUFBRSxXQUFXLFFBQVE7QUFBQSxVQUMzQjtBQUFBLHdEQUFDO0FBQUEsY0FBSSxLQUFLLEVBQUUsTUFBTSxXQUFXLGNBQWMsUUFBUTtBQUFBLGNBQUc7QUFBQSxhQUV0RDtBQUFBLFlBQ0EsNENBQUMscUJBQVE7QUFBQSxZQUNULDRDQUFDO0FBQUEsY0FBSSxLQUFLLEVBQUUsTUFBTSxRQUFRLFdBQVcsVUFBVSxZQUFZLEdBQUc7QUFBQSxjQUFHO0FBQUEsYUFFakU7QUFBQTtBQUFBLFNBQ0o7QUFBQSxRQUNBLDZDQUFDO0FBQUEsVUFBSSxLQUFLLEVBQUUsV0FBVyxRQUFRO0FBQUEsVUFDM0I7QUFBQSx3REFBQztBQUFBLGNBQUksS0FBSyxFQUFFLE1BQU0sV0FBVyxjQUFjLFFBQVE7QUFBQSxjQUFHO0FBQUEsYUFFdEQ7QUFBQSxZQUNBLDRDQUFDLHFCQUFRO0FBQUEsWUFDVCw0Q0FBQztBQUFBLGNBQUksS0FBSyxFQUFFLE1BQU0sUUFBUSxXQUFXLFNBQVMsWUFBWSxHQUFHO0FBQUEsY0FBRztBQUFBLGFBRWhFO0FBQUEsWUFDQSw0Q0FBQztBQUFBLGNBQUksS0FBSyxFQUFFLE1BQU0sUUFBUSxXQUFXLFNBQVMsWUFBWSxHQUFHO0FBQUEsY0FBRztBQUFBLGFBRWhFO0FBQUEsWUFDQSw0Q0FBQztBQUFBLGNBQUksS0FBSyxFQUFFLE1BQU0sUUFBUSxXQUFXLFNBQVMsWUFBWSxHQUFHO0FBQUEsY0FBRztBQUFBLGFBRWhFO0FBQUE7QUFBQSxTQUNKO0FBQUEsUUFDQSw2Q0FBQztBQUFBLFVBQUksS0FBSyxFQUFFLFdBQVcsUUFBUTtBQUFBLFVBQzNCO0FBQUEsd0RBQUM7QUFBQSxjQUFJLEtBQUssRUFBRSxNQUFNLFdBQVcsY0FBYyxRQUFRO0FBQUEsY0FBRztBQUFBLGFBRXREO0FBQUEsWUFDQSw0Q0FBQyxxQkFBUTtBQUFBLFlBQ1QsNENBQUM7QUFBQSxjQUFJLEtBQUssRUFBRSxNQUFNLFFBQVEsV0FBVyxTQUFTLFlBQVksR0FBRztBQUFBLGNBQUc7QUFBQSxhQUVoRTtBQUFBO0FBQUEsU0FDSjtBQUFBLFFBQ0EsNkNBQUM7QUFBQSxVQUFJLEtBQUssRUFBRSxXQUFXLFFBQVE7QUFBQSxVQUMzQjtBQUFBLHdEQUFDO0FBQUEsY0FBSSxLQUFLLEVBQUUsTUFBTSxXQUFXLGNBQWMsUUFBUTtBQUFBLGNBQUc7QUFBQSxhQUV0RDtBQUFBLFlBQ0EsNENBQUMscUJBQVE7QUFBQSxZQUNULDRDQUFDO0FBQUEsY0FBSSxLQUFLLEVBQUUsTUFBTSxRQUFRLFdBQVcsU0FBUyxZQUFZLEdBQUc7QUFBQSxjQUFHO0FBQUEsYUFFaEU7QUFBQTtBQUFBLFNBQ0o7QUFBQSxRQUNBLDZDQUFDO0FBQUEsVUFBSSxLQUFLLEVBQUUsV0FBVyxRQUFRO0FBQUEsVUFDM0I7QUFBQSx3REFBQztBQUFBLGNBQUksS0FBSyxFQUFFLE1BQU0sV0FBVyxjQUFjLFFBQVE7QUFBQSxjQUFHO0FBQUEsYUFFdEQ7QUFBQSxZQUNBLDRDQUFDLHFCQUFRO0FBQUEsWUFDVCw2Q0FBQztBQUFBLGNBQUksS0FBSyxFQUFFLE1BQU0sUUFBUSxXQUFXLFNBQVMsWUFBWSxHQUFHO0FBQUEsY0FBRztBQUFBO0FBQUEsZ0JBQ3pDLDRDQUFDO0FBQUEsa0JBQU8sS0FBSyxFQUFFLFlBQVksT0FBTTtBQUFBLGtCQUFHO0FBQUEsaUJBQWE7QUFBQSxnQkFBUztBQUFBO0FBQUEsYUFDakY7QUFBQSxZQUNBLDZDQUFDO0FBQUEsY0FBSSxLQUFLLEVBQUUsTUFBTSxRQUFRLFdBQVcsU0FBUyxZQUFZLEdBQUc7QUFBQSxjQUFHO0FBQUE7QUFBQSxnQkFDMUMsNENBQUM7QUFBQSxrQkFBTyxLQUFLLEVBQUUsWUFBWSxPQUFNO0FBQUEsa0JBQUc7QUFBQSxpQkFBZTtBQUFBLGdCQUFTO0FBQUEsZ0JBQW1CLDRDQUFDO0FBQUEsa0JBQU8sS0FBSyxFQUFFLFlBQVksT0FBTTtBQUFBLGtCQUFHO0FBQUEsaUJBQWM7QUFBQSxnQkFBUztBQUFBO0FBQUEsYUFDaEs7QUFBQSxZQUNBLDZDQUFDO0FBQUEsY0FBSSxLQUFLLEVBQUUsTUFBTSxRQUFRLFdBQVcsU0FBUyxZQUFZLEdBQUc7QUFBQSxjQUFHO0FBQUE7QUFBQSxnQkFDaEQsNENBQUM7QUFBQSxrQkFBTyxLQUFLLEVBQUUsWUFBWSxPQUFNO0FBQUEsa0JBQUc7QUFBQSxpQkFBZ0M7QUFBQSxnQkFBUztBQUFBO0FBQUEsYUFDN0Y7QUFBQSxZQUNBLDZDQUFDO0FBQUEsY0FBSSxLQUFLLEVBQUUsTUFBTSxRQUFRLFdBQVcsU0FBUyxZQUFZLEdBQUc7QUFBQSxjQUFHO0FBQUE7QUFBQSxnQkFDbkMsNENBQUM7QUFBQSxrQkFBTyxLQUFLLEVBQUUsWUFBWSxPQUFNO0FBQUEsa0JBQUc7QUFBQSxpQkFBZ0I7QUFBQSxnQkFBUztBQUFBLGdCQUFtRCw0Q0FBQztBQUFBLGtCQUFPLEtBQUssRUFBRSxZQUFZLE9BQU07QUFBQSxrQkFBRztBQUFBLGlCQUFPO0FBQUEsZ0JBQVM7QUFBQTtBQUFBLGFBQ2pNO0FBQUEsWUFDQSw0Q0FBQztBQUFBLGNBQUksS0FBSyxFQUFFLE1BQU0sUUFBUSxXQUFXLFNBQVMsWUFBWSxHQUFHO0FBQUEsY0FBRztBQUFBLGFBRWhFO0FBQUE7QUFBQSxTQUNKO0FBQUEsUUFFQSw2Q0FBQztBQUFBLFVBQUksS0FBSyxFQUFFLFdBQVcsUUFBUTtBQUFBLFVBQzNCO0FBQUEsd0RBQUM7QUFBQSxjQUFJLEtBQUssRUFBRSxNQUFNLFdBQVcsY0FBYyxRQUFRO0FBQUEsY0FBRztBQUFBLGFBRXREO0FBQUEsWUFDQSw0Q0FBQyxxQkFBUTtBQUFBLFlBQ1QsNkNBQUM7QUFBQSxjQUFJLEtBQUssRUFBRSxNQUFNLFFBQVEsV0FBVyxTQUFTLFlBQVksR0FBRztBQUFBLGNBQUc7QUFBQTtBQUFBLGdCQUM1Qiw0Q0FBQztBQUFBLGtCQUFPLEtBQUssRUFBRSxZQUFZLE9BQU07QUFBQSxrQkFBRztBQUFBLGlCQUFVO0FBQUEsZ0JBQVM7QUFBQSxnQkFBK0MsNENBQUM7QUFBQSxrQkFBTyxLQUFLLEVBQUUsWUFBWSxPQUFNO0FBQUEsa0JBQUc7QUFBQSxpQkFBUTtBQUFBLGdCQUFTO0FBQUEsZ0JBQXNFLDRDQUFDO0FBQUEsa0JBQU8sS0FBSyxFQUFFLFlBQVksT0FBTTtBQUFBLGtCQUFHO0FBQUEsaUJBQWU7QUFBQSxnQkFBUztBQUFBLGdCQUFtQyw0Q0FBQztBQUFBLGtCQUFPLEtBQUssRUFBRSxZQUFZLE9BQU07QUFBQSxrQkFBRztBQUFBLGlCQUFtQjtBQUFBLGdCQUFTO0FBQUEsZ0JBQWdCLDRDQUFDO0FBQUEsa0JBQU8sS0FBSyxFQUFFLFlBQVksT0FBTTtBQUFBLGtCQUFHO0FBQUEsaUJBQUc7QUFBQSxnQkFBUztBQUFBO0FBQUEsYUFDcGU7QUFBQTtBQUFBLFNBQ0o7QUFBQSxRQUVBLDZDQUFDO0FBQUEsVUFBSSxLQUFLLEVBQUUsV0FBVyxRQUFRO0FBQUEsVUFDM0I7QUFBQSx3REFBQztBQUFBLGNBQUksS0FBSyxFQUFFLE1BQU0sV0FBVyxjQUFjLFFBQVE7QUFBQSxjQUFHO0FBQUEsYUFFdEQ7QUFBQSxZQUNBLDRDQUFDLHFCQUFRO0FBQUEsWUFDVCw2Q0FBQztBQUFBLGNBQUksS0FBSyxFQUFFLE1BQU0sUUFBUSxXQUFXLFNBQVMsWUFBWSxHQUFHO0FBQUEsY0FBRztBQUFBO0FBQUEsZ0JBRUQsNENBQUM7QUFBQSxrQkFBSyxNQUFLO0FBQUEsa0JBQW1ELFFBQU87QUFBQSxrQkFBUztBQUFBLGlCQUFxQztBQUFBLGdCQUFPO0FBQUEsZ0JBQUssNENBQUM7QUFBQSxrQkFBSyxNQUFLO0FBQUEsa0JBQTZGLFFBQU87QUFBQSxrQkFBUztBQUFBLGlCQUEyQztBQUFBLGdCQUFPO0FBQUE7QUFBQSxhQUN4VztBQUFBO0FBQUEsU0FDSjtBQUFBO0FBQUEsS0FDSjtBQUFBLEVBRVI7QUFFQSxNQUFPLHNCQUFROzs7QUM3SWYsTUFBQUEsYUFBa0Q7QUFNOUMsTUFBQUMsc0JBQUE7QUFISixNQUFNLG9CQUFvQixDQUFDLEVBQUUsYUFBYSxZQUFZLE1BQTZCO0FBRWpGLFdBQ0UsOENBQUM7QUFBQSxNQUNDLE9BQU07QUFBQSxNQUVOO0FBQUEscURBQUM7QUFBQSxVQUNDLEtBQUs7QUFBQSxZQUNILFlBQVk7QUFBQSxZQUNaLGNBQWM7QUFBQSxZQUNkLFdBQVc7QUFBQSxZQUNYLE1BQU07QUFBQSxZQUNOLFNBQVM7QUFBQSxZQUNULE9BQU87QUFBQSxVQUNUO0FBQUEsVUFBRztBQUFBLFNBRUw7QUFBQSxRQUNBLDZDQUFDLHNCQUFPO0FBQUEsUUFDUiw2Q0FBQztBQUFBLFVBQ0MsS0FBSztBQUFBLFlBQ0gsTUFBTTtBQUFBLFlBQ04sT0FBTztBQUFBLFlBQ1AsWUFBWTtBQUFBLFlBQ1osY0FBYztBQUFBLFlBQ2QsV0FBVztBQUFBLFlBQ1gsU0FBUztBQUFBLFlBQ1QsV0FBVztBQUFBLFVBQ2I7QUFBQSxVQUFHO0FBQUEsU0FFTDtBQUFBO0FBQUEsS0FDRjtBQUFBLEVBRUo7QUFFQSxNQUFPLDRCQUFROzs7QUZsQ2YsK0JBQWM7QUFDUCxNQUFNLGFBQWE7QUFRMUIsTUFBTyxtQkFBUTtBQUFBLElBQ2IsdUJBQXVCO0FBQUEsSUFDdkIscUJBQXFCO0FBQUEsSUFDckIsUUFBUTtBQUFBLElBQ1IsTUFBTTtBQUFBLElBQ04sUUFBUTtBQUFBLElBQ1IsZUFBZTtBQUFBLE1BQ2I7QUFBQSxRQUNFLGNBQWM7QUFBQSxRQUNkLFdBQVc7QUFBQSxNQUNiO0FBQUEsTUFDQTtBQUFBLFFBQ0UsY0FBYztBQUFBLFFBQ2QsV0FBVztBQUFBLE1BQ2I7QUFBQSxNQUNBO0FBQUEsUUFDRSxjQUFjO0FBQUEsUUFDZCxXQUFXO0FBQUEsTUFDYjtBQUFBLElBQ0Y7QUFBQSxJQUNBLDhCQUE4QjtBQUFBLElBQzlCLDBCQUEwQjtBQUFBLElBQzFCLGdCQUFnQjtBQUFBLE1BQ2QsMkJBQTJCO0FBQUEsUUFDekIsZUFBZTtBQUFBLFFBQ2YsYUFBYTtBQUFBLFFBQ2IsV0FBVztBQUFBLE1BQ2I7QUFBQSxNQUNBLFNBQVM7QUFBQSxRQUNQO0FBQUEsVUFDRSxhQUFhO0FBQUEsVUFDYixZQUFZO0FBQUEsUUFDZDtBQUFBLFFBQ0E7QUFBQSxVQUNFLGFBQWE7QUFBQSxVQUNiLFlBQVk7QUFBQSxRQUNkO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxJQUNBLFdBQVc7QUFBQSxFQUNiOyIsCiAgIm5hbWVzIjogWyJpbXBvcnRfdWkiLCAiaW1wb3J0X2pzeF9ydW50aW1lIl0KfQo=
