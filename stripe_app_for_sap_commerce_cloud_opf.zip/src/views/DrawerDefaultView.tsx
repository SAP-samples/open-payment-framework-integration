import { Box, ContextView, Divider, Button } from "@stripe/ui-extension-sdk/ui";
import type { ExtensionContextValue } from "@stripe/ui-extension-sdk/context";

const DrawerDefaultView = ({ userContext, environment }: ExtensionContextValue) => {

  return (
    <ContextView
      title="SAP Open Payment Framework"
    >
      <Box
        css={{
          background: "surface",
          borderRadius: "medium",
          wordBreak: "break-all",
          font: 'subheading',
          padding: "xsmall",
          color: "secondary"
        }}>
        This app is for supporting user who integrate Stripe with SAP Open Payment Framework.
      </Box>
      <Divider/>
      <Box
        css={{
          font: 'body',
          color: 'primary',
          fontWeight: 'semibold',
          borderRadius: "medium",
          marginTop: "small",
          padding: "medium",
          wordBreak: "normal",
        }}>
        💡 Please click the button with ··· in the upper right corner and then go to the app settings page to check API key and other detailed information.
      </Box>
    </ContextView>
  );
};

export default DrawerDefaultView;
