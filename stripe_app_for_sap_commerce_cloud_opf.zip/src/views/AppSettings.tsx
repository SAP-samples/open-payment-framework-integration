import {
    Box,
    Button,
    Divider,
    Icon,
    Link,
    Inline
} from "@stripe/ui-extension-sdk/ui";

const AppSettings = () => {
    return (
        <Box>
            <Box
                css={{
                    background: "container",
                    padding: "large",
                    borderRadius: "medium",
                    width: "fit"
                }}
            >
                <Box
                    css={{
                        font: "heading",
                        stack: "x",
                        alignY: "center",
                        gap: "small",
                        marginBottom: "small",
                    }}
                >
                    <Icon name="sparkle" />
                    Welcome!
                </Box>
                <Box>
                    We&apos;re grateful for your trust in combining SAP and Stripe&apos;s solutions. Your commitment to innovation drives us to deliver seamless payment experiences that empower your business. Thank you for being part of our integrated ecosystem.
                </Box>
                <Box
                    css={{
                        stack: "x",
                        gap: "small",
                        marginTop: "medium",
                    }}
                >
                    <Button type="primary" target="_blank" href="https://help.sap.com/docs/OPEN_PAYMENT_FRAMEWORK">
                        View OPF integration instructions
                        <Icon name="external" />
                    </Button>

                    <Button type="primary" target="_blank" href="https://github.com/SAP-samples/open-payment-framework-integration/tree/main/postman/stripe">
                        OPF Stripe Integration samples
                        <Icon name="external" />
                    </Button>
                </Box>
            </Box>
            <Box css={{ marginTop: "large" }}>
                <Box css={{ font: "heading", marginBottom: "small" }}>
                    Introduction
                </Box>
                <Divider />
                <Box css={{ font: "body", marginTop: "medium", marginLeft: 10 }}>
                    This app is designed to facilitate the integration of SAP Commerce Cloud, open payment framework(OPF) with Stripe.
                </Box>
            </Box>
            <Box css={{ marginTop: "large" }}>
                <Box css={{ font: "heading", marginBottom: "small" }}>
                    Key Features
                </Box>
                <Divider />
                <Box css={{ font: "body", marginTop: "small", marginLeft: 10 }}>
                    • Generate a secure API credential for seamless authentication with Stripe
                </Box>
                <Box css={{ font: "body", marginTop: "small", marginLeft: 10 }}>
                    • Secure API access with properly scoped permissions
                </Box>
                <Box css={{ font: "body", marginTop: "small", marginLeft: 10 }}>
                    • Simplified integration process for OPF users
                </Box>
            </Box>
            <Box css={{ marginTop: "large" }}>
                <Box css={{ font: "heading", marginBottom: "small" }}>
                    User Requirements
                </Box>
                <Divider />
                <Box css={{ font: "body", marginTop: "small", marginLeft: 10 }}>
                    This app is essential for all OPF users planning to integrate their systems with Stripe. Users should have administrator access to their Stripe account and a basic understanding of API authentication principles.
                </Box>
            </Box>
            <Box css={{ marginTop: "large" }}>
                <Box css={{ font: "heading", marginBottom: "small" }}>
                    Integration Guide
                </Box>
                <Divider />
                <Box css={{ font: "body", marginTop: "small", marginLeft: 10 }}>
                    The generated Access API credential should be added to your OPF configuration in the Stripe integration section. This key allows OPF to make authenticated requests to Stripe&apos;s API on your behalf, while limiting access to only the necessary endpoints required for payment processing.
                </Box>
            </Box>
            <Box css={{ marginTop: "large" }}>
                <Box css={{ font: "heading", marginBottom: "small" }}>
                    Getting Started
                </Box>
                <Divider />
                <Box css={{ font: "body", marginTop: "small", marginLeft: 10 }}>
                    1. Click the &quot;<Inline css={{ fontWeight: "bold"}}>View API Keys</Inline>&quot; button on upper right corner.
                </Box>
                <Box css={{ font: "body", marginTop: "small", marginLeft: 10 }}>
                    2. Copy both your <Inline css={{ fontWeight: "bold"}}>Publishable Key</Inline> and the generated <Inline css={{ fontWeight: "bold"}}>Restricted Key</Inline>.
                </Box>
                <Box css={{ font: "body", marginTop: "small", marginLeft: 10 }}>
                    3. Open the <Inline css={{ fontWeight: "bold"}}>Open Payment Framework workbench</Inline> in your environment.
                </Box>
                <Box css={{ font: "body", marginTop: "small", marginLeft: 10 }}>
                    4. Navigate to the &quot;<Inline css={{ fontWeight: "bold"}}>Manage Variables</Inline>&quot; section in the OPF workbench and update the <Inline css={{ fontWeight: "bold"}}>API key</Inline> configuration.
                </Box>
                <Box css={{ font: "body", marginTop: "small", marginLeft: 10 }}>
                    5. Test the integration to ensure proper authentication.
                </Box>
            </Box>

            <Box css={{ marginTop: "large" }}>
                <Box css={{ font: "heading", marginBottom: "small" }}>
                    Rotate API Key
                </Box>
                <Divider />
                <Box css={{ font: "body", marginTop: "small", marginLeft: 10 }}>
                    In the Stripe Dashboard, locate <Inline css={{ fontWeight: "bold"}}>Developers</Inline> in the bottom-left corner and open it. Select <Inline css={{ fontWeight: "bold"}}>API Keys</Inline>, where you can find all API keys associated with the account. In the <Inline css={{ fontWeight: "bold"}}>Restricted keys</Inline> section, find the key named &quot;<Inline css={{ fontWeight: "bold"}}>Key for com.sap.opf</Inline>&quot; with the <Inline css={{ fontWeight: "bold"}}>App</Inline> tag, then click the three-dot menu at the end of the row and select Rotate.
                </Box>
            </Box>

            <Box css={{ marginTop: "large" }}>
                <Box css={{ font: "heading", marginBottom: "small" }}>
                    About OPF
                </Box>
                <Divider />
                <Box css={{ font: "body", marginTop: "small", marginLeft: 10 }}>
                    SAP Commerce Cloud, open payment framework, is a SaaS solution for managing your payment integrations in an intuitive and effective way.
                    For detailed integration instructions, please refer to the <Link href="https://help.sap.com/docs/OPEN_PAYMENT_FRAMEWORK" target="_blank"> Open Payment Framework Documentation</Link> and <Link href="https://github.com/SAP-samples/open-payment-framework-integration/tree/main/postman/stripe" target="_blank"> Open Payment Framework Integration samples</Link>.
                </Box>
            </Box>
        </Box>
    );
};

export default AppSettings;